<?php
/**
 * Created by PhpStorm.
 * User: pavel
 * Date: 08.03.2018
 * Time: 21:56
 */
?>


<?php $__env->startSection('content'); ?>

    <?php if($post): ?>
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="page-header">
                        <h3><?php echo e($post->title); ?></h3>
                    </div>

                    <img src="http://start-hse.ru/storage/<?php echo e($post->image); ?>" alt="Здесь должна быть картинка" width="700px" align="center"><br><br>
                    <?php echo $post->body; ?>

                </div>
                <div class="col-md-3">
                    slidebar
                </div>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>