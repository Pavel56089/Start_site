<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <div class="page-header">
                    <h3>Мероприятия:</h3>
                </div>
                <div class="row">
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        
                            
                                
                            
                        
                        
                            
                            
                                
                            
                            
                            
                            
                                
                                
                            
                        
                    
                    

                        <div class="col-sm-6 col-md-4">
                            <div class="thumbnail">
                                <img src="http://pro-turizm.com/wp-content/uploads/2013/10/nice-7.jpg" alt="">
                                <div class="caption">
                                    <h3><?php echo e($event->title); ?></h3>
                                    <p><?php echo e($event->desc); ?> , <?php echo e($event->status); ?> , <?php echo e($event->datetime); ?></p>
                                    <p><a href="<?php echo e(route ('eventShow',['id'=>$event->id])); ?>" class="btn btn-primary" role="button">Подробнее</a></p>
                                </div>
                            </div>
                        </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>



            </div>
            <div class="col-md-3">
                slidebar
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>