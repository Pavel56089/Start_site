<?php $__env->startSection('content'); ?>

    <?php if($event): ?>
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="page-header">
                        <h3><?php echo e($event->title); ?></h3>
                    </div>

                    <img src="<?php echo e($event->img); ?>" alt="Здесь должна быть картинка" width="700px" align="center"><br><br>
                    <?php echo e($event->desc); ?>

                </div>
                <div class="col-md-3">
                    slidebar
                </div>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>